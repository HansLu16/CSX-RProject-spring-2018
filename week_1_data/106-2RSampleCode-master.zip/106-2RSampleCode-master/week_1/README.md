## R_資料科學程式設計

### week_1

- course_1
    - practice_1.R
    - practice_2.R
    - practice_3.R
- hw_1
    - hw_1_question.R